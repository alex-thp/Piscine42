ldapwhoami -Q | cut -b 4-
