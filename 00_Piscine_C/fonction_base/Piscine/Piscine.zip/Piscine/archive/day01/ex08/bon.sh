#!/bin/sh
ldapsearch -Q | grep cn: | grep BON | wc -l | tr -d ' '
