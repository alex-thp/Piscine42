#!/bin/sh
find . -name "*.sh" | sed 's#.*/##' | rev | cut -b 4- | rev
