/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/11 18:29:46 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/15 21:14:52 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int size;
	int compteur;

	i = 0;
	compteur = 0;
	if (to_find[i] == '\0')
		return (str);
	size = ft_strlen(to_find);
	while (to_find[compteur] && str[i])
	{
		if (str[i] == to_find[compteur])
			compteur++;
		else
			compteur = 0;
		if (compteur == size)
			return (&str[i - (size - 1)]);
		i++;
	}
	return (0);
}
