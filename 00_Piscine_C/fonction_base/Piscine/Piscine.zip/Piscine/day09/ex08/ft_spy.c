/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/14 01:06:09 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/14 01:20:39 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int size;
	int compteur;

	i = 0;
	compteur = 0;
	if (to_find[i] == '\0')
		return (str);
	size = ft_strlen(to_find);
	while (to_find[compteur] && str[i])
	{
		if (str[i] == to_find[compteur])
			compteur++;
		else
			compteur = 0;
		if (compteur == size)
			return (&str[i - (size - 1)]);
		i++;
	}
	return (NULL);
}

int		main(void)
{
	char word1[] = "
}
