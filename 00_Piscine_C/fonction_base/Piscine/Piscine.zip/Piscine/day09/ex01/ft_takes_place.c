/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/13 17:51:39 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/14 11:29:06 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_takes_place(int hour)
{
	printf("THE FOLLOWING TAKES PLACE BETWEEN ");
	if (hour > 10 && hour < 21)
		printf("%02d.00 P.M. AND %02d.00 P.M.\n", (hour - 10), (hour - 9));
	else if (hour == 10)
		printf("12.00 P.M. AND 01.00 P.M.\n");
	else if (hour == 22)
		printf("12.00 A.M. AND 01.00 A.M.\n");
	else if (hour == 9)
		printf("11.00 A.M. AND 12.00 P.M.\n");
	else if (hour == 21)
		printf("11.00 P.M. AND 12.00 A.M.\n");
	else if (hour >= 0 && hour <= 10)
		printf("%02d.00 A.M. AND %02d.00 A.M.\n", (hour + 2), (hour + 3));
	else if (hour >= 23)
		printf("01.00 A.M. AND 02.00 A.M.\n");
}
