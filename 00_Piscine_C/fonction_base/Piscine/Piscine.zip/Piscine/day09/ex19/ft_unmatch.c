/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unmatch.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/14 14:14:04 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/14 14:58:41 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		compare(int *tab, int length)
{
	int j;
	int tmp;

	j = 0;
	tmp = 0;
	while (j < (length - 1))
	{
		if (((tab[j] - tab[j + 1]) != 0) && (tab[j + 1] - tab[j + 2]) != 0)
			tmp = tab[j + 1];
		j++;
	}
	return (tmp);
}

int		ft_unmatch(int *tab, int length)
{
	int i;
	int tmp;

	i = 0;
	while (i < length)
	{
		if (tab[i] > tab[i + 1])
		{
			tmp = tab[i + 1];
			tab[i + 1] = tab[i];
			tab[i] = tmp;
			i = -1;
		}
		i++;
	}
	return (compare(tab, length));
}
