ifconfig | grep inet | grep -v inet6 | grep broadcast | cut -d ' ' -f 2 || echo "Je suis perdu!\n"
