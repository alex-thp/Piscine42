cat Phonebook | grep -ia "nicolas	bauer" | awk '{ print $(NF -1) }' | grep '-'
