/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_destroy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/13 23:01:32 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/14 00:15:36 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ft_ultimate.h>

void	ft_destroy(char ***factory)
{
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	while (factory[i][j])
	{
		while (factory[i])
		{
			free(factory[i][j]);
			i++;
		}
		free(factory[j]);
		j++;
	}
	free(factory);
}
