/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_perso.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvigne <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/07/14 09:40:49 by bvigne            #+#    #+#             */
/*   Updated: 2017/07/14 10:04:52 by bvigne           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PERSO
#define FT_PERSO

#include <string.h>

typedef struct
{
	const char *name;
	int life;
	int age;
	enum profession {SAVE_THE_WORLD, SECRET_AGENT};
}t_perso;

#endif
