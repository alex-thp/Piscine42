#include "bsq.h"

char	*first_char_read(char *str)
{
	int		file;
	char	*buf;
	int		i;
	char	*tab;

	i = 0;
	if(!(buf = malloc(sizeof(char) + 1)))
		return (0);
	if(!(tab = (char*)malloc(sizeof(char) + 1)))
		return (0);
	file = open(str, O_RDONLY);
	if	(file < 0)
		ft_putstr_out("map error\n Can't open file\n", 2);
	while (*buf != '\n')
	{
		read(file, buf, 1);
		ft_strcat(tab, buf);
		ft_realloc(tab, i, (i + 1));
		i++;
	}
	close(fd);
	return (tab);
}

t_coord		*parse_first_char(char *str, t_coord *ptr)
{
	int		len;
	int		i;
	char	tmp[5];
	int		nblignes;

	nblignes = ft_unsigned_atoi(str);
	if (nblignes <= 0)
		ft_putstr_out("map error\nNot enough lines\n", 2);
	i = 0;
	len = ft_strlen(str);
	while (i <= 4)
		tmp[i++] = str[len--];
	tmp[i] = '\0';
	if (tmp[2] == tmp[3] || tmp[3] == tmp[4] || tmp[2] == tmp[4])
		ft_putstr_out("map error\nArgs are the same\n", 2);
	ptr.full = tmp[2];
	ptr.empty = tmp[3];
	ptr.to_write = tmp[4];
	ptr.nblignes = nblignes;
	ptr.first_line_len = ft_strlen(str);
	return (ptr);
}
