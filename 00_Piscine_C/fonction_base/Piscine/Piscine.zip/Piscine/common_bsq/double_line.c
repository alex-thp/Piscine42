#include "bsq.h"

t_struct	*double_line(char *str, t_struct *ptr)
{
	int		i;
	int		file;
	char	**tab;
	char	*buf;
	int		j;

	tab = (char**)malloc(sizeof(char) * ptr.nblignes * ptr.first_line_len);
	if (!tab)
		return (0);
	if(!(buff = (char*)malloc(sizeof(char) + 1)))
		return (0);
	while (tab[j])
	{
		i = 0;
		while(tab[j][i])
		{
			read(file, buf, 1);
			tab[j][i] = buf;
			i++;
		}
		j++;
	}
	ptr.double_str = tab;
	return (ptr);
}
