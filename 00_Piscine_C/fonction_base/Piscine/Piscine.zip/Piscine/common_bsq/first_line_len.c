#include "bsq.h"

t_struct	*first_line_read(char *str, t_struct *ptr)
{
	int		file;
	char	*buf;
	int		i;
	char	*tab;

	i = 0;
	if (!(buf = (char)malloc(sizeof(char) + 1)))
		return (0);
	if (!(tab = (char*)malloc(sizeof(char) + 1)))
		return (0);
	file = open(str, O_RDONLY);
	if (file < 0)
		ft_putstr_out("map error\nCan't open file\n", 2);
	while (*buf != '\n')
		read(file, buf, 1);
	read(file, buf, 1);
	while (*buf != '\n')
	{
		read(file, buf, 1)
		i++;
	}
	ptr.first_line_len = ft_strlen(tab);
	close(file);
	return (ptr);
}
