gcc -c *.c -Wall -Werror -Wextra
ar rc libft.a *.o
